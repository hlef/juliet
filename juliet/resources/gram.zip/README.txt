                                                
 .oooooooo oooo d8b  .oooo.   ooo. .oo.  .oo.   
888' `88b  `888""8P `P  )88b  `888P"Y88bP"Y88b  
888   888   888      .oP"888   888   888   888  
`88bod8P'   888     d8(  888   888   888   888  
`8oooooo.  d888b    `Y888""8o o888o o888o o888o 
d"     YD                                       
"Y88888P'                                       
                                                

Content-focused Juliet theme.

juliet version: v0.3
